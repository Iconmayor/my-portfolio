'use client'

import { useState, useEffect } from 'react'
import { Menu } from 'lucide-react'

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const closeMenu = () => {
    setIsMenuOpen(false)
  }

  useEffect(() => {
    const handleScroll = () => {
      if (isMenuOpen) {
        setIsMenuOpen(false)
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [isMenuOpen])

  return (
    <header className="bg-white dark:bg-gray-800 shadow-md fixed top-0 left-0 right-0 z-50">
      <nav className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="text-2xl font-bold">
          Paul <span className="text-yellow-500">Mayor</span>
        </div>
        <div className="hidden md:flex space-x-4">
          <NavLink href="#home">Home</NavLink>
          <NavLink href="#about">About</NavLink>
          <NavLink href="#experience">Experience</NavLink>
          <NavLink href="#projects">Projects</NavLink>
          <NavLink href="#contact">Contact</NavLink>
        </div>
        <div className="md:hidden">
          <button onClick={toggleMenu} className="focus:outline-none">
            <Menu size={24} />
          </button>
        </div>
      </nav>
      {isMenuOpen && (
        <div className="md:hidden bg-white dark:bg-gray-800 py-2">
          <NavLink href="#home" onClick={closeMenu}>Home</NavLink>
          <NavLink href="#about" onClick={closeMenu}>About</NavLink>
          <NavLink href="#experience" onClick={closeMenu}>Experience</NavLink>
          <NavLink href="#projects" onClick={closeMenu}>Projects</NavLink>
          <NavLink href="#contact" onClick={closeMenu}>Contact</NavLink>
        </div>
      )}
    </header>
  )
}

const NavLink = ({ href, children, onClick }: { href: string; children: React.ReactNode; onClick?: () => void }) => (
  <a href={href} className="block py-2 px-4 text-gray-700 dark:text-gray-300 hover:text-yellow-500 dark:hover:text-yellow-500 transition duration-300" onClick={onClick}>
    {children}
  </a>
)

export default Header

