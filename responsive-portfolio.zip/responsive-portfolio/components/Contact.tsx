import { Mail, Phone, MapPin, Star } from 'lucide-react'

const Contact = () => {
  return (
    <section id="contact" className="container mx-auto px-4 py-16 bg-gradient-to-r from-yellow-400 to-yellow-600 dark:from-yellow-600 dark:to-yellow-800">
      <h2 className="text-4xl font-bold text-center mb-12 text-white">Get in Touch</h2>
      <div className="grid md:grid-cols-3 gap-8">
        <ContactCard
          icon={<Mail className="w-8 h-8" />}
          title="Email"
          content="iconmayor1@gmail.com"
          link="mailto:iconmayor1@gmail.com"
        />
        <ContactCard
          icon={<Phone className="w-8 h-8" />}
          title="Phone"
          content="+234 8071637033"
          link="tel:+2348071637033"
        />
        <ContactCard
          icon={<MapPin className="w-8 h-8" />}
          title="Location"
          content="Lagos, Nigeria"
          link="https://www.google.com/maps/place/Lagos,+Nigeria"
        />
      </div>
      <div className="mt-16 bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg max-w-2xl mx-auto">
        <h3 className="text-2xl font-semibold mb-6 text-center">Client Testimonials</h3>
        <div className="space-y-8">
          <TestimonialCard
            name="John Doe"
            role="CEO, Tech Corp"
            content="Paul's work on our website was exceptional. He delivered a beautiful, functional site that exceeded our expectations."
            rating={5}
          />
          <TestimonialCard
            name="Jane Smith"
            role="Marketing Director, Brand Co"
            content="The digital marketing campaign Paul ran for us yielded amazing results. Our leads increased significantly."
            rating={5}
          />
          <TestimonialCard
            name="Mike Johnson"
            role="Founder, Startup Inc"
            content="Paul's expertise in both development and marketing was crucial for our product launch. Highly recommended!"
            rating={5}
          />
        </div>
      </div>
    </section>
  )
}

const ContactCard = ({ icon, title, content, link }: { icon: React.ReactNode; title: string; content: string; link: string }) => (
  <a href={link} target="_blank" rel="noopener noreferrer" className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md flex flex-col items-center text-center hover:transform hover:scale-105 transition-transform duration-300">
    <div className="bg-yellow-500 p-3 rounded-full mb-4">
      {icon}
    </div>
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-gray-600 dark:text-gray-300">{content}</p>
  </a>
)

const TestimonialCard = ({ name, role, content, rating }: { name: string; role: string; content: string; rating: number }) => (
  <div className="border-b border-gray-200 dark:border-gray-700 pb-6 last:border-b-0 last:pb-0">
    <div className="flex items-center mb-4">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={`w-5 h-5 ${i < rating ? 'text-yellow-500 fill-current' : 'text-gray-300 dark:text-gray-600'}`}
        />
      ))}
    </div>
    <p className="text-gray-700 dark:text-gray-300 mb-4 italic">&ldquo;{content}&rdquo;</p>
    <div>
      <h4 className="font-semibold">{name}</h4>
      <p className="text-sm text-gray-600 dark:text-gray-400">{role}</p>
    </div>
  </div>
)

export default Contact

