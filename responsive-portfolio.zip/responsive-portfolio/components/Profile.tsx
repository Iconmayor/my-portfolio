import Image from 'next/image'
import { Linkedin, Facebook, Github } from 'lucide-react'

const Profile = () => {
  return (
    <section id="profile" className="container mx-auto px-4 py-16 flex flex-col md:flex-row items-center justify-center gap-8">
      <div className="w-64 h-64 relative">
        <Image
          src="/assets/profile-pic.jpg"
          alt="Paul Mayor profile picture"
          width={256}
          height={256}
          className="rounded-full"
        />
      </div>
      <div className="text-center md:text-left">
        <p className="text-lg mb-2">Hello, I'm</p>
        <h1 className="text-4xl font-bold mb-4">Paul Mayor</h1>
        <p className="text-xl mb-6">A Frontend Developer & A Digital Marketer</p>
        <div className="flex justify-center md:justify-start space-x-4 mb-6">
          <button className="bg-white text-black border border-black px-6 py-2 rounded-full hover:bg-yellow-500 transition duration-300">
            Download CV
          </button>
          <button className="bg-black text-white px-6 py-2 rounded-full hover:bg-yellow-500 hover:text-black transition duration-300">
            Contact Info
          </button>
        </div>
        <div className="flex justify-center md:justify-start space-x-4">
          <SocialIcon Icon={Linkedin} href="https://linkedin.com/" />
          <SocialIcon Icon={Facebook} href="https://facebook.com/" />
          <SocialIcon Icon={Github} href="https://github.com/" />
        </div>
      </div>
    </section>
  )
}

const SocialIcon = ({ Icon, href }: { Icon: React.ElementType; href: string }) => (
  <a href={href} target="_blank" rel="noopener noreferrer" className="text-black hover:text-yellow-500 transition duration-300">
    <Icon size={24} />
  </a>
)

export default Profile

