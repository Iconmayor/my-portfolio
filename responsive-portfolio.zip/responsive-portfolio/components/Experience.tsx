import { CheckCircle } from 'lucide-react'

const Experience = () => {
  return (
    <section id="experience" className="container mx-auto px-4 py-16 bg-gray-100">
      <p className="text-center text-lg mb-2">Explore My</p>
      <h2 className="text-3xl font-bold text-center mb-8">Experience</h2>
      <div className="grid md:grid-cols-2 gap-8">
        <ExperienceCard
          title="Frontend Development"
          skills={[
            { name: "HTML", level: "Experienced" },
            { name: "CSS", level: "Experienced" },
            { name: "SASS", level: "Intermediate" },
            { name: "JavaScript", level: "Basic" },
            { name: "React", level: "Intermediate" },
          ]}
        />
        <ExperienceCard
          title="Digital Marketing"
          skills={[
            { name: "Search Engine Optimization (SEO)", level: "Basic" },
            { name: "Social Media Marketing", level: "Intermediate" },
            { name: "Email Marketing", level: "Intermediate" },
            { name: "Pay-Per-Click (PPC) Advertising", level: "Intermediate" },
          ]}
        />
      </div>
    </section>
  )
}

const ExperienceCard = ({ title, skills }: { title: string; skills: { name: string; level: string }[] }) => (
  <div className="bg-white p-6 rounded-lg shadow-md">
    <h3 className="text-2xl font-semibold mb-4">{title}</h3>
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {skills.map((skill, index) => (
        <div key={index} className="flex items-center">
          <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
          <div>
            <h4 className="font-medium">{skill.name}</h4>
            <p className="text-sm text-gray-600">{skill.level}</p>
          </div>
        </div>
      ))}
    </div>
  </div>
)

export default Experience

