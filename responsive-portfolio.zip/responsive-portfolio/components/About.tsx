import Image from 'next/image'
import { Briefcase, GraduationCap } from 'lucide-react'

const About = () => {
  return (
    <section id="about" className="container mx-auto px-4 py-16">
      <p className="text-center text-lg mb-2">Get To Know More</p>
      <h2 className="text-3xl font-bold text-center mb-8">About <span className="text-yellow-500">Me</span></h2>
      <div className="flex flex-col md:flex-row items-center gap-8">
        <div className="w-64 h-64 relative">
          <Image
            src="/assets/mayor profile.png"
            alt="Profile picture"
            layout="fill"
            objectFit="cover"
            className="rounded-lg"
          />
        </div>
        <div className="flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <ExperienceCard
              icon={<Briefcase className="w-8 h-8" />}
              title="Experience"
              description="3+ years Frontend Development & Digital Marketing"
            />
            <ExperienceCard
              icon={<GraduationCap className="w-8 h-8" />}
              title="Education"
              description="B.Sc. Bachelors Degree in Computer Science"
            />
          </div>
          <p className="text-gray-700">
            I'm Paul, a versatile professional with expertise in both marketing strategies and web development. 
            I'm skilled in Digital Marketing and Frontend Development, excelling in creating SEO-driven content, 
            managing social media, and running data-driven campaigns, while also building responsive, user-friendly 
            websites using HTML, CSS, and JavaScript to drive engagement and conversions.
          </p>
        </div>
      </div>
    </section>
  )
}

const ExperienceCard = ({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) => (
  <div className="bg-white p-4 rounded-lg shadow-md">
    {icon}
    <h3 className="text-xl font-semibold mt-2 mb-1">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
)

export default About

