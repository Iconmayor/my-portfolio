import Image from 'next/image'

const Projects = () => {
  return (
    <section id="projects" className="container mx-auto px-4 py-16">
      <p className="text-center text-lg mb-2">Browse My Recent</p>
      <h2 className="text-3xl font-bold text-center mb-8">Projects</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <ProjectCard
          title="WordPress Project"
          description="A custom WordPress theme development for a client's blog"
          imageSrc="/assets/wordpress-project.jpg"
        />
        <ProjectCard
          title="Frontend Development"
          description="A responsive web application built with React and Next.js"
          imageSrc="/assets/frontend-project.jpg"
        />
        <ProjectCard
          title="Lead Generation Campaign"
          description="A successful digital marketing campaign that increased leads by 150%"
          imageSrc="/assets/lead-gen-project.jpg"
        />
      </div>
    </section>
  )
}

const ProjectCard = ({ title, description, imageSrc }: { title: string; description: string; imageSrc: string }) => (
  <div className="bg-white rounded-lg shadow-md overflow-hidden">
    <Image src={imageSrc} alt={title} width={400} height={200} className="w-full h-48 object-cover" />
    <div className="p-4">
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      <div className="flex justify-between">
        <button className="bg-black text-white px-4 py-2 rounded hover:bg-yellow-500 transition duration-300">
          Github
        </button>
        <button className="bg-yellow-500 text-black px-4 py-2 rounded hover:bg-black hover:text-white transition duration-300">
          Live Demo
        </button>
      </div>
    </div>
  </div>
)

export default Projects

