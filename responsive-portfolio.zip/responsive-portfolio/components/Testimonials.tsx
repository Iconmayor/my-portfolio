import { Star } from 'lucide-react'

const Testimonials = () => {
  return (
    <section id="testimonials" className="container mx-auto px-4 py-16 bg-gray-100 dark:bg-gray-900">
      <h2 className="text-3xl font-bold text-center mb-8">What Clients Say</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <TestimonialCard
          name="John Doe"
          role="CEO, Tech Corp"
          content="Paul's work on our website was exceptional. He delivered a beautiful, functional site that exceeded our expectations."
          rating={5}
        />
        <TestimonialCard
          name="Jane Smith"
          role="Marketing Director, Brand Co"
          content="The digital marketing campaign Paul ran for us yielded amazing results. Our leads increased significantly."
          rating={4}
        />
        <TestimonialCard
          name="Mike Johnson"
          role="Founder, Startup Inc"
          content="Paul's expertise in both development and marketing was crucial for our product launch. Highly recommended!"
          rating={5}
        />
      </div>
    </section>
  )
}

const TestimonialCard = ({ name, role, content, rating }: { name: string; role: string; content: string; rating: number }) => (
  <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md flex flex-col justify-between h-full">
    <div>
      <div className="flex items-center mb-4">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`w-5 h-5 ${i < rating ? 'text-yellow-500 fill-current' : 'text-gray-300 dark:text-gray-600'}`}
          />
        ))}
      </div>
      <p className="text-gray-700 dark:text-gray-300 mb-4">{content}</p>
    </div>
    <div>
      <h3 className="font-semibold">{name}</h3>
      <p className="text-sm text-gray-600 dark:text-gray-400">{role}</p>
    </div>
  </div>
)

export default Testimonials

