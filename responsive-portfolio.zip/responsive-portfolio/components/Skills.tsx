import { Code, Palette, BarChart } from 'lucide-react'

const Skills = () => {
  return (
    <section id="skills" className="container mx-auto px-4 py-16">
      <h2 className="text-3xl font-bold text-center mb-8">My Skills</h2>
      <div className="grid md:grid-cols-3 gap-8">
        <SkillCard
          icon={<Code className="w-12 h-12 text-yellow-500" />}
          title="Web Development"
          description="HTML, CSS, JavaScript, React, Next.js"
        />
        <SkillCard
          icon={<Palette className="w-12 h-12 text-yellow-500" />}
          title="Graphic Design"
          description="Canva, Photoshop, Illustrator, Figma"
        />
        <SkillCard
          icon={<BarChart className="w-12 h-12 text-yellow-500" />}
          title="Digital Marketing"
          description="SEO, Social Media, Email Marketing, PPC"
        />
      </div>
    </section>
  )
}

const SkillCard = ({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) => (
  <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md text-center">
    <div className="mb-4">{icon}</div>
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-gray-600 dark:text-gray-300">{description}</p>
  </div>
)

export default Skills

